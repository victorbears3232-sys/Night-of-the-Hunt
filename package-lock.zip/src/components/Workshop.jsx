// Workshop.jsx — the Hunter's Nightmare forge. Two tabs: Reinforce the Saw
// Cleaver with Bloodstone Shards, or acquire and equip cosmetic weapon skins
// (same stats, different look). Some skins must be earned before they can be bought.

import React, { useEffect, useState } from 'react';
import { SKINS } from '@/game/WeaponSkins';

const MAX_LEVEL = 10;
const costFor = (lvl) => 2 + lvl * 2;

export default function Workshop({ game }) {
  const [tab, setTab] = useState('reinforce');
  const [, force] = useState(0);
  useEffect(() => { const id = setInterval(() => force(n => n + 1), 120); return () => clearInterval(id); }, []);
  const g = game.current;
  if (!g) return null;
  const p = g.player;
  const close = () => g.closeWorkshop();

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center px-4" style={{ background: 'rgba(0,0,0,0.84)' }} onClick={close}>
      <div className="w-full max-w-md border bg-stone-950/95 p-6 md:p-7 animate-rise" onClick={(e) => e.stopPropagation()}
        style={{ borderColor: 'rgba(200,110,50,0.4)', boxShadow: '0 0 40px rgba(200,110,50,0.14)' }}>
        <div className="text-center mb-4">
          <p className="text-amber-300/60 tracking-[0.4em] uppercase text-xs mb-1">The Workshop</p>
          <h2 className="text-stone-100 text-lg" style={{ fontFamily: 'ui-serif, Georgia, serif' }}>The Blacksmith's Forge</h2>
        </div>

        <div className="flex gap-1.5 mb-4">
          <Tab active={tab === 'reinforce'} onClick={() => setTab('reinforce')}>Reinforce</Tab>
          <Tab active={tab === 'skins'} onClick={() => setTab('skins')}>Skins</Tab>
        </div>

        {tab === 'reinforce' ? <Reinforce g={g} p={p} /> : <Skins g={g} p={p} />}

        <button onClick={close}
          className="mt-5 w-full py-2.5 text-stone-400 tracking-[0.3em] uppercase text-xs border border-stone-800 hover:border-stone-600 hover:text-stone-200 transition-colors">
          Leave the Forge
        </button>
      </div>
      <style>{`@keyframes rise { from { opacity:0; transform: translateY(12px); } to { opacity:1; transform:none; } } .animate-rise { animation: rise 0.22s ease-out both; }`}</style>
    </div>
  );
}

function Tab({ active, onClick, children }) {
  return (
    <button onClick={onClick} className="flex-1 py-2 text-[10px] tracking-[0.25em] uppercase transition-colors"
      style={{ color: active ? '#f0d8a0' : '#8a7a5a', border: `1px solid ${active ? 'rgba(200,130,60,0.6)' : 'rgba(120,80,40,0.3)'}`, background: active ? 'rgba(200,130,60,0.12)' : 'transparent', fontFamily: 'ui-serif, Georgia, serif' }}>
      {children}
    </button>
  );
}

function Reinforce({ g, p }) {
  const lvl = p.weaponLvl;
  const maxed = lvl >= MAX_LEVEL;
  const cost = costFor(lvl);
  const afford = p.shards >= cost;
  return (
    <>
      <div className="px-4 py-3 mb-4 border border-stone-800 bg-black/40">
        <div className="flex justify-between items-center mb-1">
          <span className="text-stone-200 text-sm" style={{ fontFamily: 'ui-serif, Georgia, serif' }}>Saw Cleaver</span>
          <span className="text-amber-300/90 font-mono text-sm">+{lvl}{maxed ? ' (Max)' : ''}</span>
        </div>
        <div className="flex justify-between text-[11px]">
          <span className="text-stone-500">Bloodstone Shards</span>
          <span className="text-amber-200/80 font-mono">{p.shards}{!maxed ? ` / ${cost}` : ''}</span>
        </div>
      </div>
      {maxed ? (
        <p className="text-center text-amber-200/70 italic text-sm py-4" style={{ fontFamily: 'ui-serif, Georgia, serif' }}>
          The blade has taken all the edge the forge can give. No more Bloodstone will bite it.
        </p>
      ) : (
        <>
          <div className="px-4 py-3 mb-4 border border-amber-900/40 bg-amber-950/10">
            <p className="text-amber-200/80 text-[10px] tracking-[0.3em] uppercase mb-1.5">Next Reinforcement</p>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-stone-400 text-sm">+{lvl}</span>
              <span className="text-amber-400/70">→</span>
              <span className="text-amber-200 text-sm font-semibold">+{lvl + 1}</span>
            </div>
            <p className="text-stone-300 text-[12px] italic mb-1">Damage increases: <span className="text-stone-100">+4 light / +6 heavy</span></p>
            <p className="text-stone-500 text-[11px]">Cost: <span className={afford ? 'text-amber-300' : 'text-red-400'}>{cost} Bloodstone {afford ? '' : '— not enough'}</span></p>
          </div>
          <button onClick={() => g.upgradeWeapon()} disabled={!afford}
            className={`w-full py-3 text-xs tracking-[0.3em] uppercase border transition-colors ${afford ? 'border-amber-700/60 text-amber-100 hover:bg-amber-900/20 cursor-pointer' : 'border-stone-800 text-stone-600 cursor-not-allowed'}`}
            style={{ fontFamily: 'ui-serif, Georgia, serif' }}>
            Reinforce ({cost} Shards)
          </button>
        </>
      )}
    </>
  );
}

function Skins({ g, p }) {
  const equipped = p.skin || 'default';
  return (
    <>
      <p className="text-center text-stone-500 text-[11px] italic mb-3" style={{ fontFamily: 'ui-serif, Georgia, serif' }}>
        Cosmetic only — the same steel, a different look. Some skins must be earned.
      </p>
      <div className="space-y-2 max-h-[46vh] overflow-y-auto pr-1">
        {SKINS.map(s => {
          const owned = !!(p.skins && p.skins.has(s.id));
          const isEq = equipped === s.id;
          const unlocked = !s.unlock || s.unlock(g);
          const afford = p.essence >= (s.price || 0);
          return (
            <div key={s.id} className={`w-full flex items-center gap-3 px-3 py-3 border ${isEq ? 'border-amber-600/70 bg-amber-900/10' : s.legendary ? 'border-amber-700/40 bg-amber-950/10' : 'border-stone-800'}`}>
              <div style={{ width: 46, height: 14, background: s.steel, borderTop: `2px solid ${s.serrate}`, borderBottom: `2px solid ${s.steelDark}`, flexShrink: 0, boxShadow: 'inset 0 0 6px rgba(0,0,0,0.5)' }} />
              <div className="text-left flex-1 min-w-0">
                <div className="text-stone-200 text-sm flex items-center gap-2">
                  {s.name}
                  {s.legendary && <span className="text-[9px] tracking-widest uppercase" style={{ color: '#e0b040' }}>✦ Legendary</span>}
                  {isEq && <span className="text-amber-300 text-[9px] tracking-widest uppercase">Worn</span>}
                </div>
                <div className="text-stone-600 text-[11px] italic leading-tight">{s.desc}</div>
              </div>
              {!unlocked ? (
                <span className="text-stone-600 text-[9px] tracking-widest uppercase text-right">Locked</span>
              ) : owned ? (
                <button onClick={() => g.equipSkin(s.id)} disabled={isEq}
                  className={`px-3 py-2 text-[10px] tracking-widest uppercase border ${isEq ? 'border-stone-800 text-stone-600 cursor-default' : 'border-amber-700/60 text-amber-100 hover:bg-amber-900/20 cursor-pointer'}`}>
                  {isEq ? 'Equipped' : 'Equip'}
                </button>
              ) : (
                <button onClick={() => g.buySkin(s.id)} disabled={!afford}
                  className={`px-3 py-2 text-[10px] tracking-widest uppercase border whitespace-nowrap ${afford ? 'border-amber-700/60 text-amber-100 hover:bg-amber-900/20 cursor-pointer' : 'border-stone-800 text-stone-600 cursor-not-allowed'}`}>
                  {afford ? `Buy · ${s.price} ✦` : `${s.price} ✦`}
                </button>
              )}
            </div>
          );
        })}
      </div>
    </>
  );
}