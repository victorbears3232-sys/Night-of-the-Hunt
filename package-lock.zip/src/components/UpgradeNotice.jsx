// UpgradeNotice.jsx — a small top-right notification that slides in when the
// hunter has gathered enough Bloodstone to reinforce their weapon. Auto-hides
// after ~3.5s. Keyed by notice.id so each new eligible tier re-triggers it.

import React, { useEffect, useState } from 'react';

export default function UpgradeNotice({ notice, onDone }) {
  const [phase, setPhase] = useState('in'); // in | hold | out

  useEffect(() => {
    if (!notice) return;
    setPhase('in');
    const t1 = setTimeout(() => setPhase('hold'), 320);
    const t2 = setTimeout(() => setPhase('out'), 3300);
    const t3 = setTimeout(() => onDone && onDone(), 3850);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [notice && notice.id]);

  if (!notice) return null;

  const transform = phase === 'in' ? 'translateX(120%)' : 'translateX(0)';
  return (
    <div style={{
      position: 'absolute', top: 84, right: 16, zIndex: 30,
      transform, opacity: phase === 'out' ? 0 : 1,
      transition: 'transform 0.4s cubic-bezier(.2,.8,.2,1), opacity 0.5s ease',
      maxWidth: 280, pointerEvents: 'none',
    }}>
      <div className="px-4 py-3 border" style={{
        background: 'linear-gradient(135deg, rgba(30,22,14,0.96), rgba(18,12,8,0.97))',
        borderColor: 'rgba(200,130,60,0.55)',
        boxShadow: '0 0 22px rgba(200,130,60,0.25)',
        fontFamily: 'ui-serif, Georgia, serif',
      }}>
        <div className="flex items-center gap-2 mb-0.5">
          <span className="text-amber-400 text-base">◆</span>
          <span className="text-amber-200 tracking-[0.18em] uppercase text-[11px] font-semibold">Weapon Upgrade Available</span>
        </div>
        <p className="text-stone-400 text-[10px] italic leading-tight">Visit the Blacksmith in the Hunter's Nightmare.</p>
      </div>
    </div>
  );
}